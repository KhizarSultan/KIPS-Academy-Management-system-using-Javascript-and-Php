<?php 
   include('dbcon.php');   
    $Stid = "16f8153";
   $stpass =   "786k";	
  ?>
<!DOCTYPE html>
<html><head>
<title>Welcome User</title>


<style>
*{
margin:0px;
padding:0px;	
	
}


.Mast
{
  position:relative;
  top:50px;
  left:10px;
  width:300px;
  height:590px;
  background-color:#000;
  border-bottom-left-radius:0px;
  border-bottom-right-radius:150px;
  border-top-left-radius:0px;
  border-top-right-radius:150px;  
  overflow-x:hidden;	
}
.Mast button[type="button"]
{
  font-family:Constantia, "Lucida Bright", "DejaVu Serif", Georgia, serif;	
  font-size:16px;
  border-style:none;
  border-radius:5px;	
  padding:10px;
  position:relative;
  left:30px;
  margin:20px 20px;	
  background-color:#f1f1f1;
  transition:1s;
  cursor:pointer;
  width:100px;	
}
.Mast button[type="button"]:hover
{
	
    background-color:#FF3B3B;
	text-transform:uppercase;
	transform:rotate(20deg);
	width:140px;
	color:white;	
}
.home input[type="text"]
{
	padding:3px;
	margin:15px;
	position:relative;
	left:50px;
    top:5px;
	background-color:#F5FFFA;
	color:blue;
    border-style:none;
	font-weight:bold;
	font-size:16px;
	width:180px;
	font-style:italic;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
    transition:0.5s;		
}
.home label
{
	position:relative;
	left:50px;
	top:5px;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	font-style:italic;
	color:white;
	background-color:transparent;	
	transition:0.5s;
}
.home label:hover
{
	color:red;
	cursor:pointer;	
}
.home input[type="text"]:hover
{
	background-color:#f1f1f1;
	color:#000;
	width:220px;
  	
	
}
.cources input[type="text"]
{
	padding:3px;
	margin:15px;
	position:relative;
	left:50px;
    top:5px;
	background-color:#F5FFFA;
	color:blue;
    border-style:none;
	font-weight:bold;
	font-size:16px;
	width:180px;
	font-style:italic;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
    transition:0.5s;		
}
.cources label
{
	position:relative;
	left:50px;
	top:5px;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	font-style:italic;
	color:#FFFFE0;
	background-color:transparent;	
	transition:0.5s;
}
.cources label:hover
{
	color:red;
	cursor:pointer;	
}
.cources input[type="text"]:hover
{
	background-color:#f1f1f1;
	color:#000;
	width:220px;
}
.result input[type="text"]
{
	padding:3px;
	margin:15px;
	position:relative;
	left:50px;
    top:5px;
	background-color:#000;
	color:#f1f1f1;
    border-style:none;
	font-weight:bold;
	font-size:16px;
	width:180px;
	font-style:italic;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
    transition:0.5s;		
}
.result label
{
	position:relative;
	left:50px;
	top:5px;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	font-style:italic;
	color:white;
	background-color:transparent;	
	transition:0.5s;
}
.result label:hover
{
	color:red;
	cursor:pointer;	
}
.result input[type="text"]:hover
{
	background-color:#f1f1f1;
	color:#000;
	width:220px;
  	
	
}
.password input[type="password"]
{
	padding:5px;
	margin:15px;
	position:relative;
	left:50px;
    top:5px;
	background-color:#000;
	color:#f1f1f1;
    border-style:none;
	font-weight:bold;
	font-size:16px;
	width:220px;
	font-style:italic;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
    transition:0.5s;		
}
.password label
{
	position:relative;
	left:50px;
	top:5px;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	font-style:italic;
	color:white;
	background-color:transparent;	
	transition:0.5s;
}
.password label:hover
{
	color:red;
	cursor:pointer;	
}
.password input[type="password"]:hover
{
	background-color:#f1f1f1;
	color:#000;
	width:220px;
}
.password input[type="submit"]
{
  position:relative;
  font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
  left:180px;
  top:50px;
  border-style:none;
  padding:5px;
  font-size:16px;
  border-radius:10px;
  transition:2s;	
}
.password input[type="submit"]:hover
{
	
	background-color:#000;
	color:#f1f1f1;
	transform:scale(2);
	cursor:pointer;
}
.result button[type="button"]
{
  position:relative;
  font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
  left:380px;
  top:30px;
  border-style:none;
  padding:5px;
  font-size:16px;
  border-radius:10px;
  transition:1.5s;	
}
.result button[type="button"]:hover
{
	
	background-color:#000;
	color:#f1f1f1;
	transform:scale(1.5);
	cursor:pointer;
}
.marks input[type="text"]
{
	padding:3px;
	margin:15px;
	position:relative;
	left:50px;
    top:5px;
	background-color:#F5FFFA;
	color:blue;
    border-style:none;
	font-weight:bold;
	font-size:16px;
	width:180px;
	font-style:italic;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
    transition:0.5s;		
}
.marks label
{
	position:relative;
	left:50px;
	top:5px;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	font-style:italic;
	color:white;
	background-color:transparent;	
	transition:0.5s;
}
.marks label:hover
{
	color:red;
	cursor:pointer;	
}
.marks input[type="text"]:hover
{
	background-color:#f1f1f1;
	color:#000;
	width:220px;
}
.attendence input[type="text"]
{
	padding:3px;
	margin:15px;
	position:relative;
	left:50px;
    top:5px;
	background-color:#000;
	color:#f1f1f1;
    border-style:none;
	font-weight:bold;
	font-size:16px;
	width:180px;
	font-style:italic;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
    transition:0.5s;		
}
.attendence label
{
	position:relative;
	left:50px;
	top:5px;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	font-style:italic;
	color:white;
	background-color:transparent;	
	transition:0.5s;
}
.attendence:hover
{
	color:red;
	cursor:pointer;	
}
.attendence input[type="text"]:hover
{
	background-color:#f1f1f1;
	color:#000;
	width:220px;
}
</style>
<script>
function Home()
{
	document.getElementById('home').style.display = "block";
	document.getElementById('cources').style.display = "none";
	document.getElementById('marks').style.display = "none";
	document.getElementById('password').style.display = "none";
	document.getElementById('result').style.display = "none";
	document.getElementById('attendence').style.display = "none";	
}
function Marks()
{
	
	document.getElementById('home').style.display = "none";
	document.getElementById('cources').style.display = "none";
	document.getElementById('marks').style.display = "block";
	document.getElementById('password').style.display = "none";
	document.getElementById('result').style.display = "none";
	document.getElementById('attendence').style.display = "none";
	
}
function Attendence()
{
	
	document.getElementById('home').style.display = "none";
	document.getElementById('cources').style.display = "none";
	document.getElementById('marks').style.display = "none";
	document.getElementById('password').style.display = "none";
	document.getElementById('result').style.display = "none";
	document.getElementById('attendence').style.display = "block";	
}
function Cources()
{
	
	document.getElementById('home').style.display = "none";
	document.getElementById('cources').style.display = "block";
	document.getElementById('marks').style.display = "none";
	document.getElementById('password').style.display = "none";
	document.getElementById('result').style.display = "none";
	document.getElementById('attendence').style.display = "none";
	
}
function Result()
{
	
	document.getElementById('home').style.display = "none";
	document.getElementById('cources').style.display = "none";
	document.getElementById('marks').style.display = "none";
	document.getElementById('password').style.display = "none";
	document.getElementById('result').style.display = "block";
	document.getElementById('attendence').style.display = "none";
	
}
function Password()
{
	
	document.getElementById('home').style.display = "none";
	document.getElementById('cources').style.display = "none";
	document.getElementById('marks').style.display = "none";
	document.getElementById('password').style.display = "block";
	document.getElementById('result').style.display = "none";	
	document.getElementById('attendence').style.display = "none";
}
function Logout()
{
	
	window.open("https://invigorating-tails.000webhostapp.com/welcome1.php","_self");
	<?php // session_destroy(); ?>
}
function Print()
{
    window.print();	
}
</script>
</head>
<body>
<div class="head">

</div>
<div class="Mast">
<button type="button" name="btnhome" onclick="Home()">Home</button><br>
<button type="button" name="btncources" onclick="Cources()">Courses</button><br>
<button type="button" name="btnmarks" onclick="Marks()">Marks</button><br>
<button type="button" name="btnAttendence" onclick="Attendence()">Attendence</button><br>
<button type="button" name="btntranscript" onclick="Result()">Result</button><br>
<button type="button" name="btnsetting"onclick="Password()">Password</button><br>
<button type="button" name="btnlogout" onclick="Logout()">Log out</button>

</div>
<div id="home" class="home" 
   style="
  width:1100px;
  height:700px;
  background:url(home.jpg) no-repeat;
   position:relative;
   left:315px;
   top:-580px;
   border-radius:30px;
   display:none;
   ">   
 <?php 
include('dbcon.php');
   
//session_start();
//$SName = $_SESSION['Name'];   //coming student id from Index.php
//$Spass = $_SESSION['pass'];   //coming student password from index.php
//echo $SName."  ".$Spass;

//   echo $Stid."  ".$stpass;

$query = "SELECT * FROM student WHERE `Sid`='$Stid' AND `Password` ='$stpass'";
$responce = mysqli_query($con,$query);
if(!$responce)
{
    ?>
    <script>alert("Not Responding Queries")</script>
    <?php	
}
else
{
	
 while($result= mysqli_fetch_array($responce))
 {
	 ?>
      <label>Student ID :</label><input type="text" value="<?php echo $result['Sid'] ?>" readonly ><br>
      <label>First Name: </label><input type="text" value="<?php echo $result['Fname'] ?>" readonly ><br>
      <label>Last  Name :</label><input type="text" value="<?php echo $result['Lname'] ?>" readonly ><br>
      <label>Father Name :</label><input type="text" value="<?php echo $result['FatherName'] ?>" readonly ><br>
      <label>CNIC :</label><input type="text" value="<?php echo $result['Cnic'] ?>" readonly ><br>
      <label>Class :</label><input type="text" value="<?php echo $result['Class'] ?>" readonly><br>     
      <label>DOB :</label><input type="text" value="<?php echo $result['Dob'] ?>" readonly><br>        
      <label>Address :</label><input type="text" value="<?php echo $result['Address'] ?>" readonly ><br>
      <label>Contact :</label><input type="text" value="<?php echo $result['Contact'] ?>" readonly ><br>   
      <label>City :</label><input type="text" value="<?php echo $result['City'] ?>" readonly><br>               
      <label>Gender :</label><input type="text" value="<?php echo $result['Gender'] ?>" readonly><br>
      <?php 
	  
	     //  $img = $result['photo'];
	  // echo '<img src="data:image;base64,'.$img.'">
	  ?>
      
      <img src="<?php echo $result['photo'];?>" alt="PIC is Not Responding!!" width="200" height="200" style="position:relative; left:830px; top:-500px;">
      
     </div>
	 <?php
	 global $section;
	 global $fatherName;
	 global $Cnic;
	 global $DOB;
	 global $class;
	 global $FName;
	 global $Lname;
	 $section = $result['Section'];
	 $FName = $result['Fname'];
	 $fatherName = $result['FatherName'];
     $Cnic = 	$result['Cnic'];
	 $DOB = $result['Dob'];
	 $class = $result['Class'];
	 $Lname = $result['Lname'];
	 
 }
}
 ?>  
</div>
<div class="cources" id="cources" style="width:1130px;
  height:700px;
  background:url(courses3.jpg) no-repeat fixed;
   position:relative;
   left:315px;
   opacity:0.8;
   top:-580px;
   border-radius:30px;
   display:none;">
   <?php
   include('dbcon.php');

 
   $Query = "SELECT * FROM cources WHERE `StdID` = '$Stid'";
   $responce = mysqli_query($con,$Query);
   if(!$responce)
   {
    ?>
    <script>alert("Not Responding Queries")</script>
    <?php	
   }
   else 
   {
	   $count = 0;
	   while($result = mysqli_fetch_array($responce))
	   {
		   if($count==0)
		   {
			   ?>
			    <label>Student ID:</label><input type="text" value="<?php echo $result['StdID']; ?>" readonly>
                <label>Section:</label><input type="text" value="<?php echo $section; ?>" readonly><br>
		       <?php
           }
		   $count++;
		   ?> 
          <label>Course ID: </label><input type="text" value="<?php echo $result['CourseID']; ?>" readonly >
          <label>Courses(<?php echo $count; ?>): </label><input type="text" value="<?php echo $result['CName']; ?>" readonly >
          <label>Teacher Name: </label><input type="text" value="<?php $id = $result['TeacherID']; 
		  
		  $Query2 = "SELECT * FROM faculty WHERE `TID` ='$id'";
		  $Responce = mysqli_query($con,$Query2);
        if(!$Responce)
        {
         ?>
        <script>alert("Not Responding Queries")</script>
        <?php	
        }		
		$Result = mysqli_fetch_array($Responce);   	
		 echo $Result['FullName']; ?>"readonly>
         <br>
         <?php
		
	   }
   }   
   ?>
</div>

<div class="marks" id="marks" style="width:1130px;
  height:700px;
  background:url(courses2.jpg) no-repeat fixed;
   position:relative;
   left:315px;
  top:-580px;
   border-radius:30px;
   display:none;">
   <label>Student ID:</label><input type="text" value="<?php echo $Stid; ?>" readonly>
   <label>First Name: </label><input type="text" value="<?php echo  $FName; ?>" readonly >
   <label>Last Name: </label><input type="text" value="<?php echo  $Lname; ?>" readonly ><br>
   <label>Father Name :</label><input type="text" value="<?php echo $fatherName; ?>" readonly >
   <label>CNIC:</label><input type="text" value="<?php echo $Cnic; ?>" readonly>
   <label>DOB:</label><input type="text" value="<?php echo $DOB; ?>" readonly><br>
   <label>Class:</label><input type="text" value="<?php echo $class; ?>" readonly>
   <label>Section:</label><input type="text" value="<?php echo $section; ?>" readonly><br><br>
   <?php
    
	$Query4 = "SELECT * FROM testmarks WHERE `SID` = '$Stid'";
	$Responce4 = mysqli_query($con,$Query4);
	if($Responce4 == false)
	{
	    ?>
        <script>
		alert("Query Problem");
		</script>
        <?php
	}
	else if($Responce4)
	{
		$count1 = 1;
	    while($Result4 = mysqli_fetch_array($Responce4))
		{
			if($count1==1)
			{
				
    ?>
      <table style="width:100%; padding:5px; margin:5px; text-align:center; color:#f1f1f1;" border="1px none">
     
     <tr style="font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
     font-size:18px;
     font-style:italic;
     font-weight:bold;
     color:yellow;">
     <th>T-no:</th>
     <th>Course Name</th>
     <th>Teacher Name:</th>
     <th>Total Marks</th>
     <th>Max </th>
     <th>Ave </th>
     <th>Min </th>
      <th>Obtained Marks</th>
     </tr>
       
      <?php
		}
			?>
			<tr>
           <td style="padding:10px;"><?php  echo $count1; ?> </td> 
           <td style="padding:10px;font-weight:bolder;"><?php 
		     global $queryC;
			global $ResponceC;
			global $resultC;
			 global $TiD; $TiD = $Result4['TID'];
			 $queryC = "SELECT * FROM cources WHERE `TeacherID` = '$TiD'";
			 $ResponceC = mysqli_query($con,$queryC);
			 if($ResponceC == false)
			 {
				 ?>
                 <script>
			    //  alert("Query Problem");
				 </script>
                 <?php
			 }
			 else 
			 {
				$resultC=mysqli_fetch_array($ResponceC);
				echo $resultC['CName'];
			 }
		    ?> </td>
            <td style="padding:10px;font-weight:bolder; font-family:Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif; font-size:20px;"> <?php 
			 global $queryT;
			 global $ResponceT;
			 global $ResultT;
			$queryT = "SELECT * FROM faculty WHERE `TID` = '$TiD'";
			$ResponceT = mysqli_query($con,$queryT);
			if($ResponceT == false)
			{
				 ?>
                 <script>
			//   alert("Query Problem");
				 </script>
                 <?php 	
			}
			else 
			{
			    $ResultT  = mysqli_fetch_assoc($ResponceT);
				echo $ResultT['FullName'];
			}
			?></td>
           <td style="padding:10px;"> <?php echo $Result4['totalmarks'] ?> </td>
           <?php 
		   $que = "SELECT MIN(ObtainedMarks) AS minm,MAX(ObtainedMarks) AS maxm,AVG(ObtainedMarks) AS avem FROM testmarks
		   WHERE `TID` = '$TiD'";
		   $res = mysqli_query($con,$que);
		   if($res == false)
		   {
			?>
            <script>
			//alert("Query Problem");
			</script>
            <?php  
		   }
		   else 
		   {
			   $ress = mysqli_fetch_assoc($res);
			   echo $ress['maxm'];
		   }
		   ?>
           <td style="padding:10px;"> <?php echo $ress['maxm'] ?> </td>
           <td style="padding:10px;"> <?php echo $ress['avem'] ?> </td>
           <td style="padding:10px;"> <?php echo $ress['minm'] ?> </td>
           <td style="padding:10px; font-weight:bolder;"> <?php echo $Result4['ObtainedMarks'] ?> </td>
           </tr>
			<?php
			$count1++;
		}
		?>
         
		  </table>
		<?php
		
	}
   
   ?>
   
   
   
</div>
<div class="result" id="result" style="width:1130px;
  height:700px;
  background:url(air.jpg) no-repeat fixed;
   position:relative;
   left:315px;
  top:-580px;
   border-radius:30px;
   display:none;">
   <h1 style="color:#f1f1f1; text-align:center; font-style:italic;">Kips Education System</h1>
   <label>Student ID:</label><input type="text" value="<?php echo $Stid; ?>" readonly>
   <label>First Name: </label><input type="text" value="<?php echo  $FName; ?>" readonly >
   <label>Last Name: </label><input type="text" value="<?php echo  $Lname; ?>" readonly ><br>
   <label>Father Name :</label><input type="text" value="<?php echo $fatherName; ?>" readonly >
   <label>CNIC:</label><input type="text" value="<?php echo $Cnic; ?>" readonly>
   <label>DOB:</label><input type="text" value="<?php echo $DOB; ?>" readonly><br>
   <label>Class:</label><input type="text" value="<?php echo $class; ?>" readonly>
   <label>Section:</label><input type="text" value="<?php echo $section; ?>" readonly><br><br>
   
  
   <?php
    
	$Query4 = "SELECT * FROM finals WHERE `StdID` = '$Stid'";
	$Responce4 = mysqli_query($con,$Query4);
	if($Responce4 == false)
	{
	    ?>
        <script>
		alert("Query Problem");
		</script>
        <?php
	}
	else if($Responce4)
	{
		$count1 = 1;
	    while($Result4 = mysqli_fetch_array($Responce4))
		{
			if($count1==1)
			{
				
    ?>
      <table style="width:100%; padding:5px; margin:5px; text-align:center; color:#f1f1f1;" border="1px none">
     
     <tr style="font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
     font-size:18px;
     font-style:italic;
     font-weight:bold;
     color:yellow;">
     <th>SI no:</th>
     <th>Course ID</th>
     <th>Course Name</th>
     <th>Total Marks</th>
     <th>Obtained Marks</th>
     <th>Result</th>
     </tr>
       
      <?php
		}
			?>
			<tr>
           <td style="padding:10px;"><?php  echo $count1 ?> </td> 
           <td style="padding:10px;"> <?php echo $Result4['CouseID'] ?> </td>
           <td style="padding:10px;"> <?php echo $Result4['CName'] ?> </td>
           <td style="padding:10px;"> <?php echo $Result4['Tmarks'] ?> </td>
           <td style="padding:10px;"> <?php echo $Result4['Omarks'] ?> </td>
           <td style="padding:10px;"> <?php echo $Result4['Sresult'] ?> </td>
           </tr>
			<?php
			$count1++;
		}
		?>
         
		  </table>
		<?php
		
	}
   
   ?>
   <button type="button" name="btnlprint" onclick="Print()">Print Result Card</button>
</div>
<div class="password" id="password" style="width:1130px;
  height:700px;
  background:url(password.jpg) no-repeat fixed;
   position:relative;
   left:315px;
   top:-580px;
   border-radius:30px;
   display:none;">
   <form action="Welcome.php" method="post" class="pass" name="changepassword">
   <label>Current Password:</label><input type="password" name="opass" placeholder="Enter Current Password...."><br>
   <label>New Password:</label><input type="password" name="npass" placeholder="Enter New Password...."><br>
   <label>Confirm Password:</label><input type="password" name="cpass" placeholder="Enter Confirm Password...."><br>
   <input type="submit" name="Btnpass" value="Change Password">
   </form>            
   <?php
   if(isset($_POST['Btnpass']))
   {
	   ?>
       <script>
	   
	   </script>
       
       
       <?php
	   
	   
	   include('dbcon.php');
      $opass = $_POST['opass'];
	  $npass = $_POST['npass'];
	  $cpass = $_POST['cpass'];
	  if($stpass != $opass)
	  {
		  ?>
          <script>
		 // alert("Current Password is not matching!!!");
		  </script>
          <?php
	  }
	  else if($npass == $cpass) 
	  {
		  $Query3 = "UPDATE student `Password` = '$npass' WHERE `Sid` = '$Stid'";
		  $Responce3 = mysqli_query($con,$Query3);
		  if($Responce3==true)
		  {
	      ?>
        <script>
     	alert("Password update!!!")
        </script>
         <?php
		  }
		  else 
		  {
			 ?>
            <script>
	     alert("You are Visitor, You Can't Update Password, Sorry!!!")
          </script>
           <?php		  
		  }
	  }
	  else
	  {
		?>
        <script>
		alert("New password and Confirm Password is not Matching!!!");
		</script>
        <?php  
	  }   
   }
   ?>
</div>
<div class="attendence" id="attendence" style="width:1130px;
  height:700px;
  background:url(alee.jpg) no-repeat fixed;
   position:relative;
   left:315px;
  top:-580px;
   border-radius:30px;
   display:none;">
   <label>Student ID:</label><input type="text" value="<?php echo $Stid; ?>" readonly>
   <label>First Name: </label><input type="text" value="<?php echo  $FName; ?>" readonly >
   <label>Last Name: </label><input type="text" value="<?php echo  $Lname; ?>" readonly ><br>
   <label>Father Name :</label><input type="text" value="<?php echo $fatherName; ?>" readonly >
   <label>CNIC:</label><input type="text" value="<?php echo $Cnic; ?>" readonly>
   <label>DOB:</label><input type="text" value="<?php echo $DOB; ?>" readonly><br>
   <label>Class:</label><input type="text" value="<?php echo $class; ?>" readonly>
   <label>Section:</label><input type="text" value="<?php echo $section; ?>" readonly><br><br>
   <?php
    
	$Query4 = "SELECT * FROM cources WHERE `StdID` = '$Stid'";
	$Responce4 = mysqli_query($con,$Query4);
	if($Responce4 == false)
	{
	    ?>
        <script>
		alert("Query Problem");
		</script>
        <?php
	}
	else if($Responce4)
	{
		$count1 = 1;
	    while($Result4 = mysqli_fetch_array($Responce4))
		{
			if($count1==1)
			{
				
    ?>
      <table style="width:100%;padding:5px; margin:5px; text-align:center; color:#f1f1f1;" border="1px none">
     
     <tr style="font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif;
     font-size:18px;
     font-style:italic;
     font-weight:bold;
     color:yellow;">
     <th>T-no:</th>
     <th>Course Name</th>
     <th>Teacher Name:</th>
     <th>Attendence</th>
     <th>Date</th>
     </tr>
       
      <?php
		}
			?>
			<tr>
           <td style="padding:10px;color:#f1f1f1;"><?php  echo $count1; ?> </td> 
           <td style="padding:10px;color:#f1f1f1;"><?php 
		     global $queryC;
			global $ResponceC;
			global $resultC;
			 global $TiD; $TiD = $Result4['TeacherID'];
			 $queryC = "SELECT * FROM cources WHERE `TeacherID` = '$TiD'";
			 $ResponceC = mysqli_query($con,$queryC);
			 if($ResponceC == false)
			 {
				 ?>
                 <script>
			    //  alert("Query Problem");
				 </script>
                 <?php
			 }
			 else 
			 {
				$resultC=mysqli_fetch_array($ResponceC);
				echo $resultC['CName'];
			 }
		    ?> </td>
            <td style="padding:10px;color:#f1f1f1;"> <?php 
			 global $queryT;
			 global $ResponceT;
			 global $ResultT;
			$queryT = "SELECT * FROM faculty WHERE `TID` = '$TiD'";
			$ResponceT = mysqli_query($con,$queryT);
			if($ResponceT == false)
			{
				 ?>
                 <script>
			//   alert("Query Problem");
				 </script>
                 <?php 	
			}
			else 
			{
			    $ResultT  = mysqli_fetch_assoc($ResponceT);
				echo $ResultT['FullName'];
			}
			?></td>
          
           <?php 
		   $que = "SELECT * FROM attendence WHERE `SID` = '$Stid'";
		   $res = mysqli_query($con,$que);
		   if($res == false)
		   {
			?>
            <script>
			//alert("Query Problem");
			</script>
            <?php  
		   }
		   else 
		   {
			   $ress = mysqli_fetch_assoc($res);
		   }
		   ?>
           <td style="padding:10px;color:#f1f1f1"> <?php echo $ress['ASTATUS'] ?> </td>
           <td style="padding:10px;color:#f1f1f1"> <?php echo $ress['Date'] ?> </td>
           </tr>
			<?php
			$count1++;
		}
		?>
		  </table>
		<?php	
	}
   ?>
</div>
</body>
</html>