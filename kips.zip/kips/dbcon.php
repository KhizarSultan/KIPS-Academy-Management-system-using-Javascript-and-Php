<?php
 if ($con = mysqli_connect('localhost','id6077525_khizar','sultanibro786','id6077525_kips'))
    {
	    echo "";	
	}
	   
else 
   {
	 ?>
	 <script>
	   alert("Connection Failed");
	 </script>
	  <?php    
   }
?>
