<html>
<head>
<title>Welcome Guidence</title>
<script type="text/javascript" language="javascript">
loadweb();
function loadweb()
{
   var bio = "Welcome to My Website!! It's My DataBase Lab Project and been honored for me to learn this course from Mam Anmol Bilal and Sir Tayyab. This Website facilitates the students, they can login and view their bio-data , Test-Marks, Daily-Attendence, Courses and many more!!  You are a visitor , you can login using RegNo = 16f8153 and password  = 786k  . Thank you So much !";	
   var images = [
    "beach.jpg",
	"cute.jpg",
	"landscape.jpg",
	"mountain.jpg",
	"planet.jpg",
	"train.jpg" 
   ];
   var colors = [
	  "white"
   ];	
  i=0,j=0,k=0;
  var bioSet = setInterval(showBio,50);
  var imgSet = setInterval(showImg,1500);
  function showBio()
  {
	if(i==bio.length || k== colors.length)
	{
	   if(i==bio.length)
	   { 
	   clearInterval(bioSet);
	   document.getElementById('back').style.backgroundColor = "black";
	   document.getElementById('back').style.opacity = "0.8"; 
	   document.getElementById('btn').style.display = "block";
	   }
	   else k = 0;	
	}
	else
	{
    document.getElementById('wel').innerHTML = document.getElementById('wel').innerHTML + bio[i];  
	document.getElementById('wel').style.color = colors[k];
	i++;k++;
	}
  }
  function showImg()
  {
	  var slider = document.getElementById('slider');
	if(j==images.length)
	{
		j=0;
	}
	else
	{
	slider.src = images[j];
	j++;
	}
  }	
}
function gone()
{
  var set = setInterval(fun,2500);	
  function fun()
  {
	clearInterval(set);
	window.location.replace("https://invigorating-tails.000webhostapp.com/welcome1.php");
  }
	
}
</script>
<style>
*{
    margin:0px;
	padding:0px;	
}
body
{
   height:798px;
   width:1462;	
}
.wel
{
  position:relative;
  width:800px;
  height:400px;
  left:300px;
  top:-700px;
  font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-style:italic;
  font-weight:bold;
	
}
.wel input[type="submit"]
{

  position:relative;	
  font-family:Constantia, "Lucida Bright", "DejaVu Serif", Georgia, serif;	
  font-size:18px;
  top:10px;
  left:100px;
  border-style:none;
  border-radius:5px;	
  padding:5px;	
  background-color:yellow;
  transition:2s;
  display:none;
  cursor:pointer;
  width:100px;
}
.wel input[type="submit"]:hover
{
	
    transform:translateX(500px);
	background-color:green;
	font-style:italic;
	font-family:arizonia;
	font-size:24px;
	font-weight:bold;	
}
</style>
</head>

<body>
<img id="slider" src="landscape.jpg" width="1462" height="798">
<div class="wel" id="back">
<h2 style="text-align:center; line-height:50px;" id="wel"></h2>
<input type="submit" name="btnsub" onMouseOver="gone()" value="Let's Go!!" id="btn"> 
</div>
</body>
</html>