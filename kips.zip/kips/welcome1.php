<!DOCTYPE html>
<html>
<head>
<title> Login Page </title>
<style>
*{
	margin:0;
	padding:0;
}
body
{
	height:1100px;
	width:550px;	
	background:url(alee.jpg) fixed no-repeat;
	background-size:cover;	
}
.head
{
	opacity: 0.9;
    width:1000px;
	height:150px;
	position:relative;
	left:250px;
	border-radius:100px;
	background-size:cover;
	background-color:white;
	
}
.head .anim
{
   padding-left:100px;
   padding-top:60px;
   font-size:28px;
   font-weight:bolder;
   animation: 20s move infinite;
   animation-delay:3;	  
   position:relative;
}
@keyframes move
{
  0%{
	 color:yellow;
	 font-family:Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	 font-style:italic;
	 left:0px;  
	  
  }
  10%
  {
	  color:black;
	  font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
	  font-style:normal;
	  left:380px;
  }
  30%
  {
	
	color:purple;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	left:0px;  
  }
  40%
  {
	color:red;
	font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-style:oblique;
	left:120px;  
  }
   50%
  {
	  color:green;
	  font-family:"Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", Verdana, sans-serif;
	  font-style:italic;
	  font-weight:bold;
	  left:240px; 
  }
  60%{
	 color:blue;
	 font-family:Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	 font-style:italic;
	 left:380px; 
  }
  70%
  {
	  color:purple;
	  font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
	  font-style:normal;
	 left:240px;  
  }
  80%
  {
	
	color:red;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	font-weight:bolder;
	left:120px;  
	    
  }
  90%
  {
	color:yellow;
	font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-style:oblique;
	left:0px;  
  }
   100%
  {
	  color:green;
	  font-family:"Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", Verdana, sans-serif;
	  font-style:italic;
	  font-weight:bold;
	  left:0px; 
  }
  		
}


.Login
{
	width:600px;
	height:500px;
	opacity:1;
	background:url(air.jpg) fixed no-repeat;
	background-size:cover;
	border-bottom-left-radius:50px;
	border-bottom-right-radius:150px;
	border-top-left-radius:220px;
	border-top-right-radius:50px;
	border:5px dotted red;
    border-bottom-color:#3F0;
	border-left-color:#900;
	border-top-color:#FF0;
	border-right-color:#0CF;
	transition:4s;
	background-color:red;
	position:relative;
	left:800px;
	top:80px;
	animation:5s formAnim 1;
}
@keyframes formAnim
{
	
  from
  {
	  top:-20px;
	  left:0px;	  
  }
	to
	{	top:80px;
	    left:800px;		
	}	
}
.Login input[type="text"], .Login input[type="password"]
{	
  position:relative;
  top:100px;
  font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
  left:200px;
  padding:5px;
  transition:2s;	
}
.Login input[type="text"]:hover, .Login input[type="password"]:hover
{
   transform:scale(2);	
}
.Login input[type="submit"]
{
	
  position:relative;
  top:140px;
  font-family:Constantia, "Lucida Bright", "DejaVu Serif", Georgia, serif;	
  left:290px;
  font-size:18px;
  border-style:none;
  border-radius:5px;	
  padding:5px;	
  background-color:yellow;
  transition:2s;
  cursor:pointer;
  width:100px;
}
.Login input[type="submit"]:hover
{
	
    transform:rotate(360deg);
	background-color:green;
	font-style:italic;
	font-family:arizonia;	
}
.Login input[type="button"]
{
	
  position:relative;
  top:90px;
  font-family:Constantia, "Lucida Bright", "DejaVu Serif", Georgia, serif;	
  left:200px;
  font-size:18px;
  border-style:none;
  border-radius:5px;	
  padding:5px;	
  background-color:red;
  transition:2s;
  cursor:pointer;
}
.Login input[type="button"]:hover
{
	
    transform:rotate(360deg);
	background-color:yellow;
	font-style:italic;	
}
</style>
</head>
<body>
<div class="head">
<h2 class="anim" style="font-size:28px;">Welcome to Kips Management System</h2>
</div>
<form class="Login" method="post" action="welcome1.php" name="loginForm">
<input  name="reg" type="text" placeholder="16f8153" maxlength="7" title="16f8153" required>
<br><br><input  name="pass" type="password" placeholder="786k" maxlength="20" title="786k" required>
<br><br><input type="submit" name="btnsub" value="Login"> 
<br><br><input type="button" name="btncan" value="Cancel">
</form>
<?php

if(isset($_POST['btnsub']))
{
   include('dbcon.php');

$RegNumber = $_POST['reg'];
$password = $_POST['pass'];

 
  // echo $_SESSION["reg"]."  ".$_SESSION["pass"];

// echo $RegNumber."  ".$password;
  $query = "SELECT `Password` FROM `student` WHERE `Sid` = '$RegNumber'";
  $responce = mysqli_query($con,$query); 
   if($responce)
   {
	 while($result = mysqli_fetch_array($responce))
     {
	   if($password == $result['Password'])
	  {
		  
		  // $_SESSION['ID'] = $RegNumber;  //for sending Student id to welcome.php
          // $_SESSION['Pass']= $password;     // for sending Student password to Welcome.php
		 //  echo $_SESSION['ID']." ".$_SESSION['Pass'];
		 
		  
		  ?>
          <script>
		  window.location.replace("https://invigorating-tails.000webhostapp.com/welcome2.php")
		  </script>      
          <?php
		  
	  }
	  else if($password!=$result['Password'])
	  {
       ?>
       <script>
	   alert("Password is InCorrect");
	   </script>  
       <?php  
	  }
		  
	  }
   }
}
?>
</body>
</html>





